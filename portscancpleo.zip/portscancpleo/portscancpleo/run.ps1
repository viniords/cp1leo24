using namespace System.Net
using namespace System.Net.Sockets

# Inputando parametros
param($Request, $TriggerMetadata)

# Escrevendo o log:
Write-Host "POWERSHELL Portscan realizando a request."

# Definindo o alvo
$target = "https://www.fiap.com.br/"

$body = "PORTSCAN EXECUTADO COM SUCESSO. SCANEANDO PORTAS EM $target."

# Definindo as portas
$ports = 22, 80, 8080, 30000, 30718, 30951, 31038

# Realizando o port scan
foreach ($port in $ports) {
    $tcpConnection = Test-NetConnection -ComputerName $target -Port $port -WarningAction SilentlyContinue
    if ($tcpConnection.TcpTestSucceeded) {
        $body += "`nPort $port esta aberta."
    } else {
        $body += "`nPorta $port esta fechada."
    }
}

# Associando valores do Output
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = [HttpStatusCode]::OK
    Body = $body
})
